package com.nizam.training.parentalcontrol;


import android.graphics.drawable.Drawable;

public class AppInfo {
    CharSequence label;
    CharSequence packageName;
    Drawable icon;
}
