package com.nizam.training.parentalcontrol;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class AppsDrawer extends AppCompatActivity {

    private ArrayList<AppInfo> appsList;
    private RecyclerView recyclerViewLauncherApp;
    private RAdapter recyclerViewAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps_drawer);

        recyclerViewLauncherApp = findViewById(R.id.rvLauncherAppDrawer);


        setTitle("KiddieGuard Launcher");
        recyclerViewLauncherApp = findViewById(R.id.rvLauncherAppDrawer);
        recyclerViewLauncherApp.setLongClickable(true);
        recyclerViewLauncherApp.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(AppsDrawer.this, "khgjfhdg", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        ProgressDialog mProgressDialog;
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(false);
        mProgressDialog.setTitle(getString(R.string.listapp));
        mProgressDialog.setMessage(getString(R.string.listappdesc));
        new LauncherLoadApp(recyclerViewLauncherApp, getApplicationContext(), mProgressDialog).execute();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menulauncher, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menuItemControls:
                final SharedPreferences sharedPreferences = getSharedPreferences("PinNumber", 0);
                int pin = sharedPreferences.getInt("Pin", 0);
                if (pin == 0) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            goToSignup();
                        }
                    }, 2000);
                } else {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            goToLogin();
                        }
                    }, 2000);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void goToSignup() {
        startActivity(new Intent(this, SignupActivity.class));
        finish();
    }

    public void goToLogin() {
        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        finish();
    }

}