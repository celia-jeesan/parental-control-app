# KiddieGuardNew

KiddieGuard is a parental control app(https://en.wikipedia.org/wiki/Parental_controls). 
It having options for blocking apps, wifi, bluetooth with multiple options. 
Also app used history can be viewed through this. 
Provided multiple language support English & Tamil(for my native people).
This was done as my college project. 
Supports with kitkat to pie android versions

Application help can be found in HelpActivity
